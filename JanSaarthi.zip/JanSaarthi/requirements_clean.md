# JanSaarthi – Requirements Specification

## 1. Introduction

JanSaarthi is an AI-powered, voice-enabled guidance platform designed to help rural and semi-urban citizens in India navigate government welfare systems. The platform provides step-by-step guidance, eligibility matching, and document assistance through voice interaction in regional languages, making government services accessible to low-literacy populations, elderly users, and first-time digital service users.

## 2. Objectives

- Enable citizens to interact with government service information using voice in regional languages
- Provide clear, actionable, and localized guidance for public schemes and applications
- Reduce dependency on intermediaries and manual assistance
- Improve awareness and successful enrollment in government programs

## 3. Target Users

- Rural and semi-urban citizens
- Elderly users
- Low-literacy populations
- Visually impaired users
- First-time digital service users

## 4. Functional Requirements

### 4.1 Core Interaction

#### 4.1.1 Vernacular Voice Input
- Support voice input in at least 10+ Indian languages
- Use Amazon Transcribe for speech-to-text conversion
- Support regional accents and dialect variations
- Provide fallback to text input

#### 4.1.2 Detailed Step-by-Step Roadmaps
- Generate structured, numbered guidance
- Display output in the user's native script
- Include required documents, office/portal information, timelines, and fees

#### 4.1.3 Intelligent Eligibility Matching
- Collect user profile data (age, gender, income, location, occupation)
- Match profiles with scheme eligibility
- Use Amazon Kendra for scheme search
- Present only relevant schemes

### 4.2 Document and Application Assistance

#### 4.2.1 Document Readiness Auditor
- Maintain user document inventory
- Map scheme document requirements
- Identify missing or expired documents
- Provide acquisition guidance

#### 4.2.2 Complexity Simplifier
- Simplify legal and administrative text
- Use Amazon Bedrock models
- Generate conversational output
- Avoid bureaucratic language

#### 4.2.3 Hyper-Local Office Locator
- Identify nearest offices
- Provide name, address, contact, and directions
- Integrate geolocation services

### 4.3 Future and Advanced Features

#### 4.3.1 Multimodal Interaction
- Enable Amazon Polly TTS
- Support hands-free usage
- Allow speech customization

#### 4.3.2 Document Image Verification
- Accept document photos
- Use Amazon Textract
- Validate authenticity and completeness

#### 4.3.3 Offline-First Checklists
- Allow roadmap downloads
- Support PDF and text formats
- Cache recent guidance

## 5. Non-Functional Requirements

### 5.1 Performance
- Speech response: ≤ 3 seconds
- Guidance generation: ≤ 5 seconds
- Uptime: ≥ 99.5%

### 5.2 Scalability
- Horizontal scaling
- Support ≥ 1M MAU
- Regional deployment

### 5.3 Security
- Encryption at rest and in transit
- Compliance with Indian regulations
- Least-privilege IAM

### 5.4 Privacy
- Minimal data collection
- Transparent data usage
- Defined retention policies

### 5.5 Usability
- Low-end device optimization
- Low-bandwidth support
- Localized error handling

## 6. User Stories and Acceptance Criteria

### User Story 1: Vernacular Voice Input Support
**As a** rural citizen who is more comfortable speaking in my regional language than typing  
**I want to** interact with the platform using voice in my native language  
**So that** I can access government services without language barriers

**Acceptance Criteria:**
- WHEN a user speaks in any of the 10+ supported Indian languages, THE system SHALL accurately transcribe the speech to text with 95% accuracy
- WHEN regional accents or dialects are detected, THE system SHALL adapt recognition patterns to maintain transcription accuracy
- WHEN background noise is present, THE system SHALL filter noise and focus on the primary speaker's voice
- WHEN speech input is unclear or incomplete, THE system SHALL request clarification from the user
- THE system SHALL respond to voice commands within 3 seconds of speech completion

### User Story 2: Intelligent Step-by-Step Guidance Generation
**As a** citizen unfamiliar with government procedures  
**I want to** receive clear, step-by-step instructions for accessing welfare schemes  
**So that** I can complete the process without confusion or multiple visits

**Acceptance Criteria:**
- WHEN a user requests guidance for a specific scheme, THE system SHALL create a structured roadmap with all required steps
- WHEN generating guidance, THE system SHALL include required documents, office locations, timelines, and applicable fees
- WHEN complex bureaucratic procedures are involved, THE system SHALL break them into simple, actionable steps
- WHEN multiple pathways exist for a scheme, THE system SHALL recommend the most efficient route based on user profile
- THE system SHALL complete guidance generation within 5 seconds of request

### User Story 3: Eligibility Matching and Profile Management
**As a** citizen unsure about which schemes I qualify for  
**I want** the system to analyze my profile and suggest relevant welfare programs  
**So that** I don't miss out on benefits I'm entitled to

**Acceptance Criteria:**
- WHEN a user provides demographic information, THE system SHALL store it securely in their profile
- WHEN eligibility assessment is requested, THE system SHALL match the user profile against all available schemes
- WHEN multiple schemes match, THE system SHALL rank them by relevance and benefit amount
- WHEN eligibility criteria change, THE system SHALL update assessments and notify affected users
- THE system SHALL complete matching within 3 seconds and return results with confidence scores

### User Story 4: Document Readiness Auditing
**As a** citizen preparing to apply for government schemes  
**I want to** know which documents I have, which are missing, and which are expired  
**So that** I can gather everything needed before visiting offices

**Acceptance Criteria:**
- WHEN a user uploads or registers a document, THE system SHALL verify its type and extract key information
- WHEN document expiry dates are detected, THE system SHALL track them and alert users before expiration
- WHEN a scheme requires specific documents, THE system SHALL compare against the user's document inventory
- WHEN documents are missing or expired, THE system SHALL provide specific guidance on obtaining or renewing them
- THE system SHALL maintain a real-time status of document readiness for each applicable scheme

### User Story 5: Complexity Simplification and Language Processing
**As a** citizen with limited education  
**I want** complex government language and procedures explained in simple, conversational terms  
**So that** I can understand what I need to do

**Acceptance Criteria:**
- WHEN bureaucratic or technical language is encountered, THE system SHALL convert it to simple, conversational language
- WHEN explaining procedures, THE system SHALL use analogies and examples relevant to rural contexts
- WHEN users ask for clarification, THE system SHALL provide multiple explanations at different complexity levels
- WHEN regional cultural contexts are relevant, THE system SHALL incorporate local references and customs
- THE system SHALL maintain consistency in simplified explanations across all interactions

### User Story 6: Hyper-Local Office Location Services
**As a** citizen living in a remote area  
**I want to** find the nearest government offices with complete contact information and directions  
**So that** I can plan my visits efficiently

**Acceptance Criteria:**
- WHEN a user requests office information, THE system SHALL identify the nearest relevant offices based on user location
- WHEN office information is provided, THE system SHALL include contact details, working hours, and specific services offered
- WHEN multiple offices serve the same purpose, THE system SHALL rank them by distance and service quality
- WHEN office information changes, THE system SHALL update the database and notify affected users
- THE system SHALL provide turn-by-turn directions and estimated travel time for each office

## 7. Compliance and Governance

- MeitY compliance
- Digital India alignment
- Periodic audits

## 8. Assumptions and Dependencies

- Updated scheme data availability
- Stable AWS infrastructure
- Government cooperation
- User access to mobile devices